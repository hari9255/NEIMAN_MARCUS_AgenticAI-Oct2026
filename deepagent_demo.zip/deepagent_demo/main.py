"""CLI: problem statement -> agent codes & tests in a local sandbox -> you review push_files -> GitHub.

    python main.py "Build a CLI that converts CSV to JSON with schema inference"
    python main.py --file problem.md
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
import uuid
from pathlib import Path

from dotenv import load_dotenv
from langgraph.types import Command
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt
from rich.syntax import Syntax

from dev_agent import build_agent, cleanup, create_local_sandbox, load_github_tools

console = Console()
LANGS = {"py": "python", "md": "markdown", "js": "javascript", "ts": "typescript", "yml": "yaml",
         "yaml": "yaml", "toml": "toml", "json": "json", "sh": "bash"}


def lang(path: str) -> str:
    return LANGS.get(path.rsplit(".", 1)[-1].lower(), "text") if "." in path else "text"


def workspace_mismatches(files: list[dict], workspace: Path) -> list[str]:
    """Warn the reviewer if the pushed content differs from what is actually in the sandbox."""
    prefix = os.getenv("GITHUB_PATH_PREFIX", "").strip("/")
    issues = []
    for f in files:
        rel = f["path"][len(prefix) + 1:] if prefix and f["path"].startswith(prefix + "/") else f["path"]
        p = workspace / rel
        if not p.is_file():
            issues.append(f"{f['path']}: not in sandbox workspace")
        elif p.read_text(errors="replace") != f.get("content", ""):
            issues.append(f"{f['path']}: content differs from sandbox file")
    return issues


def review(request: dict, workspace: Path) -> dict:
    decisions = []
    for action in request["action_requests"]:
        console.rule(f"[bold yellow]HUMAN REVIEW: {action['name']}")
        console.print(Panel(action.get("description", ""), border_style="cyan"))
        files = action["args"].get("files") or []
        for issue in workspace_mismatches(files, workspace):
            console.print(f"[bold red]WARNING[/] {issue}")

        while True:
            choice = Prompt.ask("[bold]\\[a]pprove push  \\[r]eject with feedback  \\[v]iew file  \\[f]ull code[/]",
                                choices=["a", "r", "v", "f"], default="f")
            if choice in ("v", "f"):
                chosen = files
                if choice == "v":
                    for i, f in enumerate(files, 1):
                        console.print(f"  {i}. {f['path']}")
                    idx = Prompt.ask("File #", default="1")
                    chosen = [files[int(idx) - 1]] if idx.isdigit() and 0 < int(idx) <= len(files) else []
                for f in chosen:
                    console.rule(f["path"])
                    console.print(Syntax(f.get("content", ""), lang(f["path"]), line_numbers=True, word_wrap=True))
            elif choice == "a":
                decisions.append({"type": "approve"})
                break
            else:
                fb = ""
                while not fb.strip():
                    fb = Prompt.ask("What should change?")
                decisions.append({"type": "reject", "message": fb})
                break
    return {"decisions": decisions}


def print_update(update: dict) -> None:
    for data in update.values():
        if not isinstance(data, dict):
            continue
        msgs = data.get("messages") or []
        msgs = getattr(msgs, "value", msgs)
        for m in msgs if isinstance(msgs, list) else []:
            if m.type == "ai":
                if isinstance(m.text, str) and m.text.strip():
                    console.print(Panel(Markdown(m.text), title="agent", border_style="blue"))
                for tc in m.tool_calls or []:
                    a = tc["args"]
                    brief = a.get("command") or a.get("file_path") or a.get("branch") or a.get("description") or ""
                    console.print(f"[magenta]-> {tc['name']}[/] [dim]{str(brief)[:120]}[/]")
            elif m.type == "tool":
                console.print(f"[dim]   <- {m.name}: {str(m.content)[:300].replace(chr(10), ' ')}[/]")


async def run(problem: str, keep: bool) -> None:
    backend, base = create_local_sandbox(os.getenv("SANDBOX_DIR") or None)
    workspace = base / "workspace"
    console.print(f"[green]Local sandbox:[/] {workspace}")
    try:
        tools = await load_github_tools()
        console.print(f"[green]GitHub MCP tools:[/] {', '.join(t.name for t in tools)}")
        agent = build_agent(backend, tools)

        config = {"configurable": {"thread_id": str(uuid.uuid4())}, "recursion_limit": 300}
        next_input: object = {"messages": [{"role": "user", "content": problem}]}
        while True:
            interrupt = None
            async for update in agent.astream(next_input, config, stream_mode="updates"):
                print_update(update)
                if "__interrupt__" in update:
                    interrupt = update["__interrupt__"][0].value
            if interrupt:
                next_input = Command(resume=review(interrupt, workspace))
                continue
            follow_up = Prompt.ask("\n[bold]Follow-up for the agent (enter to quit)[/]", default="")
            if not follow_up.strip():
                break
            next_input = {"messages": [{"role": "user", "content": follow_up}]}
    finally:
        if keep or os.getenv("SANDBOX_KEEP") == "1":
            console.print(f"Sandbox kept at {base}")
        else:
            cleanup(base)


def main() -> None:
    load_dotenv()
    ap = argparse.ArgumentParser(description="Deep agent: problem -> code -> local sandbox -> human review -> GitHub")
    ap.add_argument("problem", nargs="?")
    ap.add_argument("--file", help="Read the problem statement from a file")
    ap.add_argument("--keep-workspace", action="store_true", help="Keep the sandbox directory at exit")
    args = ap.parse_args()

    problem = Path(args.file).read_text() if args.file else args.problem
    if not problem:
        console.print("[bold]Describe the problem (finish with an empty line):[/]")
        problem = "".join(iter(sys.stdin.readline, "\n"))
    if not problem.strip():
        sys.exit("No problem statement given.")
    asyncio.run(run(problem, args.keep_workspace))


if __name__ == "__main__":
    main()
