"""Local sandbox: deepagents' built-in LocalShellBackend on a throwaway directory.

    <tmp>/deep-dev-agent-xxxx/
        workspace/   <- the agent's virtual "/" (file tools can't leave it; `..`/`~` blocked)
        venv/        <- private Python venv used by every `execute` call
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from deepagents.backends import LocalShellBackend


def create_local_sandbox(base_dir: str | None = None, timeout: int = 120) -> tuple[LocalShellBackend, Path]:
    """Return (backend, base_dir). Delete base_dir when done (see `cleanup`)."""
    base = Path(base_dir or tempfile.mkdtemp(prefix="deep-dev-agent-")).resolve()
    workspace, venv, tmp = base / "workspace", base / "venv", base / "tmp"
    workspace.mkdir(parents=True, exist_ok=True)
    tmp.mkdir(exist_ok=True)
    if not venv.exists():
        subprocess.run([sys.executable, "-m", "venv", "--system-site-packages", str(venv)],
                       check=True, capture_output=True)

    bin_dir = venv / ("Scripts" if os.name == "nt" else "bin")
    backend = LocalShellBackend(
        root_dir=workspace,
        virtual_mode=True,      # file tools are jailed to workspace/
        timeout=timeout,
        inherit_env=False,      # API keys / GitHub token never reach code the agent runs
        env={
            "PATH": os.pathsep.join([str(bin_dir), "/usr/local/bin", "/usr/bin", "/bin"]),
            "VIRTUAL_ENV": str(venv),
            "HOME": str(base),
            "TMPDIR": str(tmp),
            "PYTHONDONTWRITEBYTECODE": "1",
            "LANG": "C.UTF-8",
        },
    )
    return backend, base


def cleanup(base: Path) -> None:
    shutil.rmtree(base, ignore_errors=True)
