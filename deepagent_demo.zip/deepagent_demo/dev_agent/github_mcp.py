"""Load tools from the official GitHub MCP server (https://api.githubcopilot.com/mcp/)."""

from __future__ import annotations

import os

from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import MultiServerMCPClient

# Only these GitHub MCP tools are given to the agent. Everything else
# (delete_file, merge_pull_request, create_repository, ...) is filtered out.
ALLOWED_TOOLS = {
    # read
    "get_file_contents", "list_branches", "list_commits", "search_code",
    # write
    "create_branch", "push_files", "create_pull_request",
}


async def load_github_tools() -> list[BaseTool]:
    client = MultiServerMCPClient({
        "github": {
            "transport": "streamable_http",
            "url": os.getenv("GITHUB_MCP_URL", "https://api.githubcopilot.com/mcp/"),
            "headers": {
                "Authorization": f"Bearer {os.environ['GITHUB_PERSONAL_ACCESS_TOKEN']}",
                "X-MCP-Toolsets": os.getenv("GITHUB_TOOLSETS", "repos,pull_requests"),
            },
        }
    })
    tools = [t for t in await client.get_tools() if t.name in ALLOWED_TOOLS]
    missing = {"create_branch", "push_files", "create_pull_request"} - {t.name for t in tools}
    if missing:
        raise RuntimeError(f"GitHub MCP server did not expose {sorted(missing)}; check GITHUB_TOOLSETS / PAT scopes.")
    return tools
