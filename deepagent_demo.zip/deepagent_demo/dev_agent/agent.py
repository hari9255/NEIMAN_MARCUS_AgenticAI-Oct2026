"""The Deep Agent: plans, codes in the local sandbox, tests, then pushes via the GitHub MCP server.

Human review uses Deep Agents' built-in `interrupt_on` (HumanInTheLoopMiddleware):
every `push_files` call pauses the graph until a human approves or rejects it.
"""

from __future__ import annotations

import os
from typing import Any

from deepagents import create_deep_agent
from langchain_core.messages import ToolMessage
from langchain_core.tools import BaseTool
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.checkpoint.memory import InMemorySaver

SYSTEM_PROMPT = """You are a senior software engineer. A developer gives you a problem statement;
you deliver working, tested code to GitHub.

## Local sandbox
- Your workspace root is `/` for the file tools (e.g. `/src/app.py`, `/tests/test_app.py`).
- `execute` runs shell commands already inside that root - use RELATIVE paths
  (`python -m pytest -q`). A private Python venv is active; `pip install` goes into it.
- Never put secrets in code.

## Workflow (follow strictly)
1. Plan with `write_todos`. If the problem is ambiguous, state your assumptions in the README.
2. Implement clean, typed code with a short README.md (what / how to run / how to test) and
   requirements.txt if you use dependencies.
3. Write pytest tests and run them with `execute`. Iterate until they all pass. Never fake or skip tests.
4. Ask the `code-reviewer` subagent (via `task`) to review; fix important findings; re-run the tests.
5. The LAST thing you run before pushing must be the full test suite with `execute`.
6. Push to GitHub with the GitHub MCP tools:
   a. `create_branch` from `{base}` named `{prefix}<kebab-case-name>` (reuse it on later attempts).
   b. `push_files` with EVERY project file in the workspace (exact file contents, paths relative to
      the root{path_note}) and a conventional commit message.
      A human reviews this call. If it is REJECTED, address every point of the feedback, re-run the
      tests, and call `push_files` again on the same branch.
   c. After a successful push, `create_pull_request` into `{base}` with a clear title and description.
7. Finish with a short report: what was built, test results, branch and PR link.

Target repository: owner=`{owner}`, repo=`{repo}`. Only ever write to this repository.
Use the read-only GitHub tools to look at existing code/conventions in it when useful.
Never claim code was pushed unless `push_files` actually succeeded.
"""

REVIEWER_PROMPT = """You are a meticulous code reviewer. Inspect the code with the file tools and run
the tests with `execute`. Report, by severity: bugs, unhandled edge cases, security issues, missing
tests, readability. Be concrete (file + line + fix). Do NOT edit files. Under 300 words."""


def _last_test_run(state: dict) -> str:
    for m in reversed(state.get("messages", [])):
        if isinstance(m, ToolMessage) and m.name == "execute":
            return str(m.content)[-6000:]
    return "(no command was run in the sandbox)"


def _push_description(tool_call: dict, state: dict, runtime: Any) -> str:
    """Shown to the human reviewer together with the push_files arguments."""
    a = tool_call["args"]
    files = a.get("files") or []
    listing = "\n".join(f"  - {f.get('path')} ({len(str(f.get('content', '')).splitlines())} lines)" for f in files)
    return (
        f"Push {len(files)} file(s) to {a.get('owner')}/{a.get('repo')}@{a.get('branch')}\n"
        f"Commit: {a.get('message')}\n{listing}\n\n"
        f"Last sandbox command output:\n{_last_test_run(state)}"
    )


def build_agent(
    backend,
    github_tools: list[BaseTool],
    *,
    model: Any | None = None,
    checkpointer: BaseCheckpointSaver | None = None,
):
    owner, repo = os.environ["GITHUB_OWNER"], os.environ["GITHUB_REPO"]
    path_prefix = os.getenv("GITHUB_PATH_PREFIX", "").strip("/")

    return create_deep_agent(
        model=model or os.getenv("MODEL", "anthropic:claude-sonnet-4-6"),
        tools=github_tools,
        system_prompt=SYSTEM_PROMPT.format(
            owner=owner,
            repo=repo,
            base=os.getenv("GITHUB_BASE_BRANCH", "main"),
            prefix=os.getenv("GITHUB_BRANCH_PREFIX", "agent/"),
            path_note=f", prefixed with `{path_prefix}/`" if path_prefix else "",
        ),
        subagents=[{
            "name": "code-reviewer",
            "description": "Reviews the sandbox code for bugs, security issues and missing tests.",
            "system_prompt": REVIEWER_PROMPT,
        }],
        backend=backend,
        # Built-in human-in-the-loop on the GitHub MCP write tool.
        interrupt_on={
            "push_files": {
                "allowed_decisions": ["approve", "reject"],
                "description": _push_description,
            },
        },
        checkpointer=checkpointer or InMemorySaver(),   # required for interrupt / resume
        name="deep-dev-agent",
    )
