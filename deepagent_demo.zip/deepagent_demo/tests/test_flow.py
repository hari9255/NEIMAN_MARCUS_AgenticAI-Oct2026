"""Offline end-to-end test: scripted LLM + real local sandbox + stand-ins for the GitHub MCP tools.

write code -> run tests in sandbox -> push_files paused for review -> REJECT -> fix -> APPROVE -> PR.
"""

from __future__ import annotations

import asyncio
import uuid
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.tools import StructuredTool
from langgraph.types import Command

from dev_agent import build_agent, cleanup, create_local_sandbox


class ScriptedModel(BaseChatModel):
    script: list[AIMessage]
    i: int = 0

    @property
    def _llm_type(self) -> str:
        return "scripted"

    def bind_tools(self, tools: Any, **kw: Any):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kw) -> ChatResult:
        msg = self.script[self.i] if self.i < len(self.script) else AIMessage("done")
        self.i += 1
        return ChatResult(generations=[ChatGeneration(message=msg)])


def call(name: str, **args) -> AIMessage:
    return AIMessage("", tool_calls=[{"name": name, "args": args, "id": f"c-{uuid.uuid4().hex[:8]}"}])


BUGGY = "def add(a, b):\n    return a - b\n"
FIXED = "def add(a, b):\n    return a + b\n"
TEST = "from calc import add\n\ndef test_add():\n    assert add(2, 3) == 5\n"
REPO = {"owner": "acme", "repo": "demo"}


def fake_github_mcp():
    """Same names/arg shapes as the GitHub MCP server tools."""
    calls: list[tuple[str, dict]] = []

    async def create_branch(owner: str, repo: str, branch: str, from_branch: str = ""):
        calls.append(("create_branch", locals().copy()))
        return "ok"

    async def push_files(owner: str, repo: str, branch: str, files: list[dict], message: str):
        calls.append(("push_files", locals().copy()))
        return "pushed"

    async def create_pull_request(owner: str, repo: str, title: str, head: str, base: str, body: str = ""):
        calls.append(("create_pull_request", locals().copy()))
        return "https://github.com/acme/demo/pull/1"

    fns = (create_branch, push_files, create_pull_request)
    return [StructuredTool.from_function(coroutine=f, name=f.__name__, description=f.__name__) for f in fns], calls


async def _run(monkeypatch):
    monkeypatch.setenv("GITHUB_OWNER", "acme")
    monkeypatch.setenv("GITHUB_REPO", "demo")
    files = lambda calc: [{"path": "calc.py", "content": calc}, {"path": "tests/test_calc.py", "content": TEST}]  # noqa: E731
    model = ScriptedModel(script=[
        call("write_file", file_path="/calc.py", content=BUGGY),
        call("write_file", file_path="/tests/test_calc.py", content=TEST),
        call("execute", command="python -m pytest -q"),
        call("create_branch", **REPO, branch="agent/add-calc", from_branch="main"),
        call("push_files", **REPO, branch="agent/add-calc", files=files(BUGGY), message="feat: add"),  # reject
        call("edit_file", file_path="/calc.py", old_string="a - b", new_string="a + b"),
        call("execute", command="python -m pytest -q"),
        call("push_files", **REPO, branch="agent/add-calc", files=files(FIXED), message="feat: add"),  # approve
        call("create_pull_request", **REPO, title="Add calc", head="agent/add-calc", base="main"),
        AIMessage("Done."),
    ])
    tools, calls = fake_github_mcp()
    backend, base = create_local_sandbox()
    try:
        agent = build_agent(backend, tools, model=model)
        cfg = {"configurable": {"thread_id": "t1"}, "recursion_limit": 100}
        nxt: Any = {"messages": [{"role": "user", "content": "write add()"}]}
        reviews = []
        decisions = iter([{"type": "reject", "message": "tests fail, fix add"}, {"type": "approve"}])
        while True:
            intr = None
            async for up in agent.astream(nxt, cfg, stream_mode="updates"):
                if "__interrupt__" in up:
                    intr = up["__interrupt__"][0].value
            if not intr:
                break
            reviews.append(intr)
            nxt = Command(resume={"decisions": [next(decisions)]})
        state = (await agent.aget_state(cfg)).values
        on_disk = (base / "workspace" / "calc.py").read_text()
        return reviews, calls, state, on_disk
    finally:
        cleanup(base)


def test_end_to_end(monkeypatch):
    reviews, calls, state, on_disk = asyncio.run(_run(monkeypatch))

    assert len(reviews) == 2
    first, second = (r["action_requests"][0] for r in reviews)
    assert first["name"] == "push_files" and "1 failed" in first["description"]   # reviewer sees real test output
    assert "1 passed" in second["description"]

    # push_files only ran after approval, and only once
    assert [n for n, _ in calls] == ["create_branch", "push_files", "create_pull_request"]
    pushed = {f["path"]: f["content"] for f in dict(calls)["push_files"]["files"]}
    assert pushed["calc.py"] == FIXED == on_disk

    rejection = [m.content for m in state["messages"] if m.type == "tool" and m.name == "push_files"][0]
    assert "tests fail, fix add" in str(rejection)


def test_sandbox_env_is_scrubbed(monkeypatch):
    monkeypatch.setenv("GITHUB_PERSONAL_ACCESS_TOKEN", "secret")
    backend, base = create_local_sandbox()
    try:
        assert "secret" not in backend.execute("env").output
        assert str(base / "workspace") in backend.execute("pwd").output
        assert str(base / "venv") in backend.execute("python -c 'import sys;print(sys.prefix)'").output
    finally:
        cleanup(base)
