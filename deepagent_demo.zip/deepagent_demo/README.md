# deep-dev-agent

A LangChain **Deep Agent** that turns a problem statement into tested code in a **local sandbox**,
then pushes it to GitHub using the **GitHub MCP server's own tools** — with a **human review** before
anything is pushed. No custom tools: only Deep Agents built-ins + GitHub MCP tools.

```
problem ─► write_todos ─► write_file / edit_file ─► execute (tests, local sandbox) ─► fix until green
        ─► task: code-reviewer subagent ─► create_branch (GitHub MCP)
        ─► push_files (GitHub MCP)  ── interrupt_on ──►  YOU: approve / reject + feedback
                                                           reject ─► agent fixes, re-tests, push_files again
                                                           approve ─► pushed ─► create_pull_request (GitHub MCP)
```

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # ANTHROPIC_API_KEY, GITHUB_PERSONAL_ACCESS_TOKEN, GITHUB_OWNER, GITHUB_REPO
python main.py "Build a Python CLI that converts CSV to JSON with type inference and tests"
```

When the agent calls `push_files`, the run pauses and you see the target branch, commit message,
file list, the **output of the last test run in the sandbox**, and a warning if any file being pushed
differs from the sandbox copy. Then:

```
[a]pprove push   [r]eject with feedback   [v]iew file   [f]ull code
```

## What's used

| Piece | Provided by |
|---|---|
| Planning, file tools, `execute`, subagents | `deepagents.create_deep_agent` |
| Local sandbox | `deepagents.backends.LocalShellBackend` on a temp dir (`dev_agent/sandbox.py`) |
| Human review | `interrupt_on={"push_files": ...}` (LangChain `HumanInTheLoopMiddleware`) |
| GitHub | GitHub MCP server via `langchain-mcp-adapters`: `create_branch`, `push_files`, `create_pull_request` + read tools |

**Local sandbox:** fresh directory per run — `workspace/` is the agent's `/` (file tools can't leave it),
a private venv is used for every command, the environment is scrubbed so your API key and GitHub token
are not visible to code the agent runs, and the directory is deleted at exit (`--keep-workspace` to keep it).
Shell commands still run as your user, so keep human review on.

**GitHub tool allow-list** (`dev_agent/github_mcp.py`): only `get_file_contents`, `list_branches`,
`list_commits`, `search_code`, `create_branch`, `push_files`, `create_pull_request` are given to the agent —
destructive tools like `delete_file` or `merge_pull_request` are filtered out.

## Layout

```
main.py                   CLI: streaming output, review prompt, interrupt/resume loop
dev_agent/agent.py        create_deep_agent(...) with interrupt_on on push_files
dev_agent/sandbox.py      local sandbox (LocalShellBackend + temp dir + venv)
dev_agent/github_mcp.py   GitHub MCP server connection + tool allow-list
tests/test_flow.py        offline E2E test (scripted LLM, real sandbox, GitHub MCP stand-ins)
```

## Tests

```bash
python -m pytest -q
```

## Resuming from your own UI

```python
async for update in agent.astream(inputs, cfg, stream_mode="updates"):
    if "__interrupt__" in update:
        req = update["__interrupt__"][0].value     # {"action_requests": [{"name": "push_files", "args": ..., "description": ...}]}
agent.astream(Command(resume={"decisions": [{"type": "approve"}]}), cfg)
agent.astream(Command(resume={"decisions": [{"type": "reject", "message": "handle empty CSVs"}]}), cfg)
```

Swap `InMemorySaver` for `SqliteSaver` / `PostgresSaver` if reviews happen later or in a web UI.
