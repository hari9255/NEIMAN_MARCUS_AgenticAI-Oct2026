import asyncio
import os
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
from langchain_mcp_adapters.tools import load_mcp_tools
from langchain.agents import create_agent
from langchain_anthropic import ChatAnthropic



async def main():
    server_params = StdioServerParameters(
    command = "npx",
    args = ["-y", "@modelcontextprotocol/server-github"],
    env= {"GITHUB_TOKEN":"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"}
    )
    # Estabilsh connect and load tools
    async with stdio_client(server_params) as (read,write):
        async with ClientSession(read,write) as session:
            await session.initialize()
            tools = await load_mcp_tools(session)
            llm = ChatAnthropic(model="claude-haiku-4-5",api_key="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")
            system_prompt = "analyze user query and pick correct tool related to github repository operations to give answer if it requires"
            user_input =  input("Enter your query: ")
            final_prompt = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_input}
                ]
            agent =create_agent(llm,tools=tools)
            result = await agent.ainvoke({"messages": final_prompt})
            print("Agent Response:", result["messages"][-1].content)

if __name__ == "__main__":
    asyncio.run(main())
            



    
            