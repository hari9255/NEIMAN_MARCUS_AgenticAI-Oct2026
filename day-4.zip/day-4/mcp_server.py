from fastmcp import FastMCP
from langchain_tavily import TavilySearch
from langchain_chroma import Chroma
from langchain_huggingface.embeddings import HuggingFaceEmbeddings
import os
import random

hf_embedding = HuggingFaceEmbeddings(model="sentence-transformers/all-mpnet-base-v2")

mcp = FastMCP("MCP_Server")
os.environ["TAVILY_API_KEY"] = "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"



@mcp.tool
def web_search_tool(query: str):
    '''
    use this tool to get latest or current information from web search

    '''
    print("web search tool is called")
    web_search = TavilySearch(max_results=3, topic="general")
    context = web_search.invoke(query)
    return context

@mcp.tool
def vector_search_tool(query: str):
    '''
    use this tool to get relevant information about company like deloitte, apple, microsoft.

    '''
    print("vector search tool is called")
    vector_search = Chroma(embedding_function=hf_embedding, persist_directory="vector_db")
    relevant_chunks = vector_search.similarity_search(query)
    final_context = "\n".join([relevant_chunk.page_content for relevant_chunk in relevant_chunks])
    return final_context


@mcp.tool
def random_number_generator():
    '''
    use this tool to generate a random number

    '''
    print("random generator tool is called")
    return random.randint(300,400)


if __name__ == "__main__":
    mcp.run(transport="sse",port=8000)