import asyncio
from langchain.agents import create_agent
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_anthropic import ChatAnthropic

client = MultiServerMCPClient(
    {
        "MCP_Server":{
            "transport":"sse",
            "url":"http://localhost:8000/sse",
        }
    }
)

async def setup_tools():
    tools = await client.get_tools()
    return tools

llm = ChatAnthropic(model="claude-haiku-4-5",api_key="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")


async def main():
    tools = await setup_tools()
    user_input =  input("Enter your query: ")
    system_prompt = "analyze user query and pick correct tool to give answer if it requires"
    final_prompt = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_input}
    ]

    agent = create_agent(llm,tools=tools)
    result = await agent.ainvoke({"messages": final_prompt})
    print("Agent Response:", result["messages"][-1].content_blocks)

if __name__ == "__main__":
    asyncio.run(main())