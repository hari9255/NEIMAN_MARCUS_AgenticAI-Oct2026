from langchain_community.document_loaders import PyPDFLoader
from pydantic import BaseModel , Field
from langchain.agents import create_agent
from langchain_anthropic import ChatAnthropic
import os
os.environ["ANTHROPIC_API_KEY"] = "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"


pdf_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample_invoice.pdf")
loader = PyPDFLoader(file_path=pdf_path)
docs = loader.load()

invoice_content = docs[0].page_content

#print("invoice content is: ", invoice_content)

class Item(BaseModel):
    item_descrition : str = Field(description="item descrition mentioned on invoice")
    quantity: int = Field(description="quantity of item purchased")
    unit_price: str = Field(description="price of single unit")
    total: str = Field(description="total value crossponding to item")

class InvoiceSchema(BaseModel):
    bill_to : str = Field(description="customer name to whom invoice is tagged")
    invoice_no : str = Field(description= "invoice no. mention on invoice")
    grand_total: str = Field(description="total amount paid by customer")
    order_date: str = Field(description="order date mention on invoice")
    order_id: str = Field(description="order id mentioned on invoice")
    items: list[Item] = Field(description="list of items mntioned on invoice")

from langchain_anthropic import ChatAnthropic

model = ChatAnthropic(
    model="claude-haiku-4-5-20251001",
    
    # max_tokens=,
    # timeout=,
    # max_retries=,
    # ...
)

agent = create_agent(
    model=model,
    response_format=InvoiceSchema
)

output = agent.invoke(
    {"messages": [{"role": "user", "content": invoice_content}]}
)


invoice = output["messages"][-1].content
print(invoice)


