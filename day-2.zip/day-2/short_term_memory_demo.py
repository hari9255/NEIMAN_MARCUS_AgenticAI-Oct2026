
from langchain_tavily import TavilySearch
from langchain.agents import create_agent
from langgraph.checkpoint.memory import InMemorySaver
import os , random


os.environ["ANTHROPIC_API_KEY"] = "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"
os.environ["TAVILY_API_KEY"] = "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"


search_tool  = TavilySearch(
    max_results=3,
    topic="general",
)

def random_number_generator():
    '''
    use this tool to generate a random number

    '''
    print("random generator tool is called")
    return random.randint(300,400)

checkpointer = InMemorySaver()

agent = create_agent(
    model="claude-haiku-4-5",
    tools=[random_number_generator,search_tool],
    system_prompt="analyze use query and pick correct tool to give answer if it requires",
    checkpointer=checkpointer
    
)

while True:
    user_input = input("enter your query: ")
    thread_config = input("enter thread Id: ")    
    thread_config = {"configurable": {"thread_id": str(thread_config)}}
    result = agent.invoke(
        {"messages": [{"role": "user", "content": user_input}]},config=thread_config)

    print(result["messages"][-1].content_blocks[-1]["text"])








