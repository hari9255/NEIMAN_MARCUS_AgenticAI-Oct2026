"""GitHub access through the official GitHub MCP server (remote, streamable HTTP).

All GitHub calls are made deterministically by the host code (not by the LLM),
so a push can only happen after the user's explicit approval.
"""
import asyncio
import base64
import concurrent.futures
import json
import os

import boto3
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

GITHUB_MCP_URL = os.getenv("GITHUB_MCP_URL", "https://api.githubcopilot.com/mcp/")


def _github_token() -> str:
    if os.getenv("GITHUB_TOKEN"):
        return os.environ["GITHUB_TOKEN"]
    secret_id = os.getenv("GITHUB_TOKEN_SECRET_ID")
    if secret_id:
        value = boto3.client("secretsmanager").get_secret_value(SecretId=secret_id)["SecretString"]
        try:
            return json.loads(value)["token"]
        except (ValueError, KeyError, TypeError):
            return value
    raise RuntimeError("Set GITHUB_TOKEN or GITHUB_TOKEN_SECRET_ID for the GitHub MCP server")


def _run(coro):
    """Run a coroutine from sync code, even if an event loop is already running in this thread."""
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        return pool.submit(asyncio.run, coro).result()


def _content_to_text(result) -> list[str]:
    out = []
    for item in result.content:
        if getattr(item, "type", None) == "text":
            out.append(item.text)
        elif getattr(item, "type", None) == "resource":
            res = item.resource
            if getattr(res, "text", None) is not None:
                out.append(res.text)
            elif getattr(res, "blob", None) is not None:
                out.append(base64.b64decode(res.blob).decode("utf-8", errors="replace"))
    return out


class GitHubMCP:
    def __init__(self):
        self.headers = {"Authorization": f"Bearer {_github_token()}"}

    async def _call_many(self, calls):
        results = []
        async with streamablehttp_client(GITHUB_MCP_URL, headers=self.headers) as (read, write, _):
            async with ClientSession(read, write) as session:
                await session.initialize()
                for name, args in calls:
                    r = await session.call_tool(name, args)
                    texts = _content_to_text(r)
                    if r.isError:
                        raise RuntimeError(f"GitHub MCP tool {name} failed: {' '.join(texts)[:2000]}")
                    results.append(texts)
        return results

    def call(self, name: str, args: dict) -> list[str]:
        return _run(self._call_many([(name, args)]))[0]

    # ---------- write side ----------
    def push(self, owner, repo, branch, files: dict, message, base_branch=None, open_pr=False, pr_body=""):
        """Push files in a single commit. If base_branch is given, the branch is created from it first."""
        calls = []
        if base_branch and base_branch != branch:
            calls.append(("create_branch", {"owner": owner, "repo": repo, "branch": branch, "from_branch": base_branch}))
        calls.append(("push_files", {
            "owner": owner, "repo": repo, "branch": branch, "message": message,
            "files": [{"path": p, "content": c} for p, c in files.items()],
        }))
        if open_pr and base_branch:
            calls.append(("create_pull_request", {
                "owner": owner, "repo": repo, "title": message, "head": branch, "base": base_branch, "body": pr_body,
            }))
        results = _run(self._call_many(calls))
        return {"branch": branch, "pull_request": "\n".join(results[-1])[:2000] if open_pr and base_branch else None}

    # ---------- read side ----------
    def fetch_files(self, owner, repo, path="", ref=None,
                    extensions=(".py", ".txt", ".toml", ".cfg", ".ini"), max_files=60) -> dict:
        """Recursively read files under `path` via get_file_contents. Returns {path: content}."""
        files: dict[str, str] = {}

        async def walk(session, p):
            if len(files) >= max_files:
                return
            args = {"owner": owner, "repo": repo, "path": p or "/"}
            if ref:
                args["ref"] = ref
            r = await session.call_tool("get_file_contents", args)
            if r.isError:
                raise RuntimeError(f"get_file_contents {p}: {' '.join(_content_to_text(r))[:500]}")
            texts = _content_to_text(r)
            # Directory listing -> JSON array of entries
            for t in texts:
                try:
                    data = json.loads(t)
                except ValueError:
                    continue
                if isinstance(data, list):
                    for entry in data:
                        if entry.get("type") == "dir":
                            await walk(session, entry["path"])
                        elif entry.get("type") == "file" and entry["path"].endswith(extensions):
                            await walk(session, entry["path"])
                    return
                if isinstance(data, dict) and "content" in data:  # older server: base64 JSON blob
                    raw = data["content"]
                    files[p] = base64.b64decode(raw).decode() if data.get("encoding") == "base64" else raw
                    return
            # Newer server: a status line + an embedded resource with the file text
            body = [t for t in texts if not t.lower().startswith("successfully downloaded")]
            if body:
                files[p] = body[-1]

        async def main():
            async with streamablehttp_client(GITHUB_MCP_URL, headers=self.headers) as (read, write, _):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    await walk(session, path.strip("/"))

        _run(main())
        return files


def split_repo(repo: str):
    owner, _, name = repo.partition("/")
    if not owner or not name:
        raise ValueError("repo must look like 'owner/name'")
    return owner, name
