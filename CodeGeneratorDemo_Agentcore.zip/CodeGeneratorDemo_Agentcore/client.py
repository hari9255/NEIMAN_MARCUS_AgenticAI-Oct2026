"""Interactive client for the Code Generator agent.

  # deployed on AgentCore Runtime
  python client.py --arn arn:aws:bedrock-agentcore:us-east-1:123:runtime/codegen-xyz \
                   --requirement sample_requirement.txt --repo myuser/my-repo
  # local (python agent.py running on :8080)
  python client.py --local --requirement sample_requirement.txt --repo myuser/my-repo
"""
import argparse
import json
import urllib.request
import uuid

import boto3
from botocore.config import Config


class Runtime:
    def __init__(self, arn=None, region="us-east-1", local=False):
        self.arn, self.local = arn, local
        self.session_id = f"codegen-{uuid.uuid4()}"  # AgentCore needs >= 33 chars
        if not local:
            self.client = boto3.client("bedrock-agentcore", region_name=region,
                                       config=Config(read_timeout=900, retries={"max_attempts": 1}))

    def invoke(self, payload: dict) -> dict:
        payload = {**payload, "session_id": self.session_id}
        if self.local:
            req = urllib.request.Request("http://localhost:8080/invocations", data=json.dumps(payload).encode(),
                                         headers={"Content-Type": "application/json",
                                                  "X-Amzn-Bedrock-AgentCore-Runtime-Session-Id": self.session_id})
            with urllib.request.urlopen(req, timeout=900) as r:
                return json.loads(r.read())
        resp = self.client.invoke_agent_runtime(agentRuntimeArn=self.arn, runtimeSessionId=self.session_id,
                                                payload=json.dumps(payload).encode())
        return json.loads(resp["response"].read())


def show(result: dict):
    if result.get("status") == "error":
        print("\nERROR:", result["error"]); return
    print("\n=== SUMMARY ===\n" + result.get("summary", ""))
    print("\n=== FILES ===")
    for p, c in result.get("files", {}).items():
        print(f"  {p}  ({len(c.splitlines())} lines)")
    t = result.get("tests", {})
    print(f"\n=== TESTS in Code Interpreter: {'PASSED' if t.get('passed') else 'FAILED'} "
          f"(runner={t.get('runner')}, exit={t.get('exit_code')}) ===")
    print("\n".join(t.get("output", "").splitlines()[-25:]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arn"); ap.add_argument("--region", default="us-east-1")
    ap.add_argument("--local", action="store_true")
    ap.add_argument("--requirement", required=True, help="path to requirement .txt file")
    ap.add_argument("--repo", required=True, help="owner/name")
    ap.add_argument("--branch", default=None)
    ap.add_argument("--base-branch", default=None, help="if set, push to a new branch and open a PR into this one")
    args = ap.parse_args()

    rt = Runtime(args.arn, args.region, args.local)
    with open(args.requirement, encoding="utf-8") as fh:
        requirement = fh.read()
    print("Generating code and testing it in AgentCore Code Interpreter (this can take a few minutes)...")
    result = rt.invoke({"action": "generate", "requirement": requirement})

    while True:
        show(result)
        if result.get("status") != "awaiting_approval":
            return
        choice = input("\n[a]pprove & push  [r]evise  [v]iew file  [x] reject > ").strip().lower()
        if choice == "v":
            name = input("file path: ").strip()
            print(result["files"].get(name, "(no such file)"))
            continue
        if choice == "r":
            result = rt.invoke({"action": "revise", "feedback": input("feedback: ")})
        elif choice == "a":
            payload = {"action": "approve", "repo": args.repo, "branch": args.branch, "base_branch": args.base_branch}
            if not result["tests"]["passed"]:
                payload["force"] = input("Tests failed. Push anyway? [y/N] ").strip().lower() == "y"
            print(json.dumps(rt.invoke(payload), indent=2)); return
        elif choice == "x":
            print(json.dumps(rt.invoke({"action": "reject"}), indent=2)); return


if __name__ == "__main__":
    main()
