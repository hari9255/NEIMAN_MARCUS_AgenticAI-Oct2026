"""Agent 1 - Code Generator (AgentCore Runtime + Strands).

Flow (all calls use the same runtimeSessionId):
  1. {"action": "generate", "requirement": "<contents of requirement.txt>"}
       -> LLM writes code + pytest tests, iterates in AgentCore Code Interpreter,
          host re-verifies, returns files + test report. Status: awaiting_approval
  2a. {"action": "revise", "feedback": "..."}       -> regenerate with feedback
  2b. {"action": "approve", "repo": "owner/name", "branch": "main",
       "base_branch": "main" (optional, creates branch + PR), "force": false}
       -> pushes via GitHub MCP push_files
  2c. {"action": "reject"}                            -> discard
"""
import json
import os
import posixpath
import time

from bedrock_agentcore.runtime import BedrockAgentCoreApp
from strands import Agent, tool
from strands.models import BedrockModel

from github_mcp import GitHubMCP, split_repo
from sandbox import Sandbox

MODEL_ID = os.getenv("MODEL_ID", "us.amazon.nova-pro-v1:0")
REGION = os.getenv("AWS_REGION", "us-east-1")

app = BedrockAgentCoreApp()
SESSIONS: dict[str, dict] = {}  # AgentCore pins a runtimeSessionId to one microVM, so this survives between calls

SYSTEM_PROMPT = """You are a senior Python engineer. Turn the user's requirement into a small,
production-quality Python project.

Layout rules:
- Application code under src/<package_name>/ (include __init__.py).
- Tests under tests/ as test_*.py using pytest; import from the package (src/ is on PYTHONPATH).
- Optional requirements.txt for third-party deps (keep deps minimal; stdlib preferred).
- A short README.md describing usage.

Process:
1. Write the code and tests.
2. Call run_in_sandbox with ALL files (full contents) to execute pytest in the AWS AgentCore Code Interpreter.
3. Read the output, fix failures, and re-run until all tests pass (max ~5 attempts).
4. Call submit_solution with the final, complete file set and a short summary. Do not paste code in chat.
"""


def _validate_paths(files: dict) -> dict:
    clean = {}
    for path, content in files.items():
        p = posixpath.normpath(path.strip().replace("\\", "/"))
        if p in ("", ".") or p.startswith(("/", "../", ".git/")) or p == "..":
            raise ValueError(f"Unsafe path from model: {path!r}")
        clean[p] = content if isinstance(content, str) else json.dumps(content)
    return clean


def generate(requirement: str, previous: dict | None = None, feedback: str | None = None) -> dict:
    submitted: dict = {}
    with Sandbox() as sb:

        @tool
        def run_in_sandbox(files: dict[str, str]) -> str:
            """Write the files into a clean AgentCore Code Interpreter workspace and run pytest.

            Args:
                files: Mapping of relative path (e.g. "src/app/core.py", "tests/test_core.py") to full file content.
            """
            return json.dumps(sb.run_tests(_validate_paths(files)))

        @tool
        def submit_solution(files: dict[str, str], summary: str) -> str:
            """Submit the final project for user review. Call exactly once, after tests pass.

            Args:
                files: Complete mapping of relative path to full file content.
                summary: 3-6 sentence description of what was built and how it was tested.
            """
            submitted["files"] = _validate_paths(files)
            submitted["summary"] = summary
            return "Submitted for user approval."

        agent = Agent(
            model=BedrockModel(model_id=MODEL_ID, region_name=REGION, temperature=0.2),
            system_prompt=SYSTEM_PROMPT,
            tools=[run_in_sandbox, submit_solution],
            callback_handler=None,
        )
        prompt = f"REQUIREMENT:\n{requirement}"
        if previous and feedback:
            prompt += (f"\n\nYou previously produced these files:\n{json.dumps(previous, indent=1)}"
                       f"\n\nThe user reviewed them and asked for changes:\n{feedback}\n"
                       "Apply the feedback, re-test, then submit the full updated file set.")
        agent(prompt)

        if "files" not in submitted:
            raise RuntimeError("Model finished without calling submit_solution")
        # Independent verification by the host - the model's own claim is not trusted.
        verification = sb.run_tests(submitted["files"])

    return {"files": submitted["files"], "summary": submitted["summary"], "tests": verification}


def _review_payload(sid: str, state: dict) -> dict:
    return {
        "session_id": sid,
        "status": state["status"],
        "summary": state["summary"],
        "files": state["files"],
        "tests": state["tests"],
        "next": "Send {action:'approve', repo:'owner/name'} to push, {action:'revise', feedback:'...'} "
                "to change, or {action:'reject'} to discard.",
    }


@app.entrypoint
def invoke(payload: dict, context=None):
    action = payload.get("action", "generate")
    sid = getattr(context, "session_id", None) or payload.get("session_id") or "local"
    state = SESSIONS.get(sid)

    try:
        if action == "generate":
            requirement = (payload.get("requirement") or "").strip()
            if not requirement:
                return {"status": "error", "error": "payload.requirement (text of the requirement file) is required"}
            result = generate(requirement)
            SESSIONS[sid] = {"requirement": requirement, "status": "awaiting_approval", **result}
            return _review_payload(sid, SESSIONS[sid])

        if state is None:
            return {"status": "error", "error": "No pending work for this session. Run action 'generate' first."}

        if action == "revise":
            result = generate(state["requirement"], previous=state["files"], feedback=payload.get("feedback", ""))
            state.update(status="awaiting_approval", **result)
            return _review_payload(sid, state)

        if action == "reject":
            SESSIONS.pop(sid, None)
            return {"session_id": sid, "status": "rejected"}

        if action == "approve":
            if state["status"] != "awaiting_approval":
                return {"status": "error", "error": f"Session is '{state['status']}', nothing to approve"}
            if not state["tests"]["passed"] and not payload.get("force"):
                return {"status": "error", "error": "Tests did not pass in Code Interpreter. Revise, or approve with force=true."}
            owner, repo = split_repo(payload["repo"])
            base = payload.get("base_branch")
            branch = payload.get("branch") or (f"agent/codegen-{int(time.time())}" if base else "main")
            message = payload.get("commit_message") or f"feat: generated by AgentCore codegen agent\n\n{state['summary'][:500]}"
            result = GitHubMCP().push(owner, repo, branch, state["files"], message,
                                      base_branch=base, open_pr=bool(base), pr_body=state["summary"])
            state["status"] = "pushed"
            return {"session_id": sid, "status": "pushed", "repo": payload["repo"], **result,
                    "files": sorted(state["files"])}

        return {"status": "error", "error": f"Unknown action {action!r}"}
    except Exception as exc:  # noqa: BLE001 - surface errors to the caller
        return {"session_id": sid, "status": "error", "error": f"{type(exc).__name__}: {exc}"}


if __name__ == "__main__":
    app.run()
