import os
os.environ["ANTHROPIC_API_KEY"] = "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"


import anthropic

client = anthropic.Anthropic()

message = client.messages.create(
    model="claude-haiku-4-5",
    max_tokens=1000,
    messages=[
        {
            "role": "user",
            "content": "Hi",
        }
    ],
)

print(message)
