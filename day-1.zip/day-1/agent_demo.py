import os
os.environ["ANTHROPIC_API_KEY"] = "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"

from langchain.agents import create_agent
import random

def random_number_generator():
    '''
    use this tool to generate a random number

    '''
    print("random generator tool is called")
    return random.randint(300,400)

agent = create_agent(
    model="claude-haiku-4-5",
    tools=[random_number_generator],
    system_prompt="analyze use query and pick correct tool to give answer if it requires",
    
)

result = agent.invoke(
    {"messages": [{"role": "user", "content": "what is capital of india? and also generate a random number?"}]}
)


print(result["messages"][-1].content_blocks)



